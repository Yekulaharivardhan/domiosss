import React, { Component } from "react";
import Counter from './counter'
import "./card.css";


const Image = "https://images.dominos.co.in/Paneer.jpg";
const img2 = "https://images.dominos.co.in/4625-CMB1211.jpg";
const img3 = "https://images.dominos.co.in/CMB1250.jpg";
const img4 = "https://images.dominos.co.in/PIZ5158_1.jpg";
const img5 = "https://images.dominos.co.in/PIZ0171.jpg";
const img6 = "https://images.dominos.co.in/PIZ5160_1.jpg";




// function createEntry(pizzaEntry){

// return<Entry 
// Key ={pizzadata.Key}
// cardimgtop ={pizzadata.cardimgtop}
// cardtitle ={pizzadata.cardtitle} 
// cardtext={pizzadata.cardtext}
// description ={pizzadata.s}
// />

// }


class Cards extends Component {
  value = this.props.value
  
  render(
    
  ) {


const CarCustomstyles = (<div className="card-body">
<h5 className="card-title">Card title</h5>
<p className="card-text">
  Some quick example text to build on the card title and make up the
  bulk of the card's content.
</p>
<Counter/>
</div>
)



  return (

         <div className="cardwrap">
      {/* <Entry 
      cardimgtop ="https://images.dominos.co.in/Paneer.jpg"
      cardtitle = "Paneer Paratha Pizza"
      cardtext="Regular"
      description ="An epic fusion of paratha and pizza with melting cheese & soft paneer fillings to satisfy all your indulgent cravings"
      />
     
      <div>
      {pizzadata.map(createEntry)}
</div> */}



        <div className="card">
          <img className="card-img-top" src={Image} alt=" " />

          <div className="img-wrpr__typ"><div className="injectStyles-sc-1jy9bcf-0 khLfXP"></div></div>

          <div className="img-wrpr__fav" data-label="favorite">


          <div className="injectStyles-sc-1jy9bcf-0 iBNnip"></div>
          <div className="injectStyles-sc-1jy9bcf-0 gmEBsn"></div></div>
          {CarCustomstyles}
            </div>
    


        <div className="card">
          <img className="card-img-top" src={img2} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img3} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img4} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img5} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img6} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img2} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img6} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img5} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img4} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img3} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img2} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={Image} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img2} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img4} alt=" " />
          {CarCustomstyles}
        </div>

        <div className="card">
          <img className="card-img-top" src={img6} alt=" " />
          {CarCustomstyles}
        </div>
      </div>
    );
  }
  
}

export default Cards;
