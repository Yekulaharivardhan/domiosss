import React, { Component } from "react";
import './counter.css'


class Counter extends Component {
  state = { cart:0} 


 
  CartStatusCounter = () => {
    this.setState({cart:this.state.cart+1})
    
  }
  CartStatusCounterDec = () => {
    this.setState({cart:this.state.cart-1})
    
  }


  render() { 


    const CustomeStyle = (<div className="itm-dsc__actn__adCrt">
    <div className="injectStyles-sc-1jy9bcf-0 jrxrSi">
    <button data-label="addTocart">
    <span onClick={this.CartStatusCounter}>ADD TO CART</span></button></div></div>)
   
    
  
  const CartStatus = this.state.cart
  

   const CustomeStyleTwo = (
    <div className="itm-dsc__actn__adCrt">
              <div className="sc-kAzzGY beBJOM" data-label="quantity">
              <div className="injectStyles-sc-1jy9bcf-0 kYAlCU" data-label="decrease" onClick={this.CartStatusCounterDec}></div>
              <span className="cntr-val">{this.state.cart}</span>
              <div>
              <div className="injectStyles-sc-1jy9bcf-0 gwKvJy" data-label="increase" onClick={this.CartStatusCounter}></div></div></div>
            </div>
  )
    
  
      const CartUpdStatus =
      CartStatus <= 0 ?  CustomeStyle : CustomeStyleTwo
  


    return (
      <div>

{CartUpdStatus}

</div>
    );
  }

  
}


 
export default Counter;
