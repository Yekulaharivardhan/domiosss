import "./App.css";
import React, { Component } from 'react';
// import SideNavBar from "./components/Navbar";
// import Navbar from "./components/Navbar";
import Cards from "./components/card";
// import NavContent from "./components/NavContent";
import Catbar from "./components/catBar";
import SecondNavBar from "./components/secondNavBar";
import CartStatusimg from "./components/cartStatus";
import NavBarTwo from './components/navBarTwo'
import LoginPage from "./logincomponents/Login";
import Entry from './components/Entry';


class App extends Component {
  
  render() { 
    return (
      
   <React.Fragment>

<main className="containertwo">

{/* <Route path="/catBar" className="Component">{Catbar}</Route>
<Route path="/secondNavBar" className="Component">{SecondNavBar}</Route>
<Route path="/navBarTwo" className="Component">{NavBarTwo}</Route> */}
      {/* <Navbar /> */}
      <NavBarTwo/>
   

      <SecondNavBar />
      {/* <Counter/> */}
      <CartStatusimg />
      {/* <NavContent /> */}
      <Catbar />
     {/* <LoginPage/> */}
      <Cards />
      {/* <Entry/> */}

</main>
      </React.Fragment>
     
);
}
}

export default App;
