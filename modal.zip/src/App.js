
import './App.css';
import BsModal from './components/modal';


function App() {
  return (
    <div className="App">
      <BsModal/>
    </div>
  );
}

export default App;
